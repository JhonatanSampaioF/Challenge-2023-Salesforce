<h1>ENTREGA SPRINT 4 CHALLENGE SALES FORCE</h1>
<p>Com a proposta da Sales Force de atrair mais clientes utilizando sua plataforma, nos ja JLV desenvolvemos um novo portal em REACT para melhor usabiliade e navegação</p>

<p>Aqui está um link de como está a plataforma e suas funcionalidades: https://www.youtube.com/watch?v=bvmnkH4yrM0</p>
<p>Aqui está o link da plataforma no vercel: https://sales-f.vercel.app/</p>