export const menuItems = [
    {
      title: "Página Inicial",
    },
    {
      title: "Produtos",
      submenu: [
        {
          title: "Sales Cloud",
        },
        {
          title: "Einstein GPT",
        }
      ],
    },
    {
      title: "Entre em Contato",
    },
  ];
  




/*import { React, useState } from "react";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCaretDown } from '@fortawesome/free-solid-svg-icons';
import { faCaretUp } from '@fortawesome/free-solid-svg-icons';

export const menuItems = [
    {
        title: "Home",
        path: "/"
    },
    {
        title: "Produtos",
        path: "/produtos",
        iconClosed: faCaretDown,
        iconOpened: faCaretUp,
        submenu: [
            {
                title: "Sales Cloud",
                path: "/produtos/sales-cloud"
            }
        ]
    },
    {
        title: "Entre em contato",
        path: "/contato",
    }
];
*/