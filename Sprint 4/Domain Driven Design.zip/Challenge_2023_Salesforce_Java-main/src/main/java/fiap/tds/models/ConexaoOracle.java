package fiap.tds.models;

public class ConexaoOracle {
    public static final String URL_CONNECTION = "jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL";
    public static final String USER = "RM553791";
    public static final String PASSWORD = "180298";
}
