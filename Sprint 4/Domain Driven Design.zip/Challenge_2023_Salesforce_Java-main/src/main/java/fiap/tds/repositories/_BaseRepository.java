package fiap.tds.repositories;

import fiap.tds.models.ConexaoOracle;

public class _BaseRepository extends ConexaoOracle {
}
