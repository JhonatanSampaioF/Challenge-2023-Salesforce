--1TDSPR
--RM553791  -  Jhonatan Sampaio Ferreira
--RM553580  -  Levi Yuki Utima
--RM553169  -  Vivian Sy Ting Wu


--Apaga tabelas com o mesmo nome, caso exista.
drop table tb_cliente cascade constraints;
drop table tb_compra cascade constraints;
drop table tb_produto cascade constraints;
drop table tb_formularioDuvidas cascade constraints;
drop table tb_especialista cascade constraints;
drop table tb_feedback cascade constraints;
drop table tb_Compra_Prod cascade constraints;


--Cria tabelas das entidades fortes
create table tb_cliente (id_clie varchar(12) constraint clie_id_pk primary key,
                         nm_clie varchar2(35) constraint clie_nm_nn not null,
                         sobrenome varchar2(35) constraint clie_sobrenome_nn not null,
                         email varchar2(70) constraint clie_email_nn not null
                                            constraint clie_email_uk unique,
                         empresa varchar2(70) constraint clie_empresa_nn not null,
                         tamanho_empresa number(4) constraint clie_tam_empresa_nn not null,
                         pais varchar2(2) constraint clie_pais_nn not null,
                         idioma varchar2(12) constraint clie_idioma_nn not null,
                         cargo varchar2(35) constraint clie_cargo_nn not null,
                         telefone varchar2(15) constraint clie_telefone_nn not null);
                         
                     
                        
create table tb_produto (id_produto varchar(12) constraint produto_id_pk primary key,
                         nm_prod varchar2(35) constraint prod_nm_nn not null
                                              constraint prod_nm_uk unique,
                         plano_prod number(1) constraint prod_plano_nn not null,
                         desc_prod varchar2(1000) constraint prod_desc_nn not null); 
                         
                         
create table tb_especialista (id_espec varchar(12) constraint espec_id_pk primary key,
                              nm_espec varchar2(35) constraint espec_nm_nn not null,
                              email_espec varchar2(70) constraint espec_email_nn not null
                                                       constraint espec_email_uk unique,
                              telefone_espec varchar2(15) constraint espec_fone_nn not null);
                              
--Cria das tabelas das entidades fracas                              
create table tb_compra (id_compra varchar(12) constraint compra_id_pk primary key,
                        dt_compra date constraint compra_data_nn not null,
                        forma_pagamento varchar(35) constraint compra_forma_pgmto_nn not null,
                        qtd_licenca number(12) constraint compra_qtd_licenca_nn not null,
                        fk_Cliente_id_clie varchar(12) references tb_cliente);   
                        

create table tb_formularioDuvidas (id_form varchar(12) constraint form_id_pk primary key,
                                   dt_form date constraint form_dt_nn not null,
                                   desc_form varchar2(1000) constraint form_desc_nn not null,
                                   seg_empresa varchar2(35) constraint form_empresa_nn not null,
                                   fk_Cliente_id_clie varchar(12) references tb_cliente,
                                   fk_Especialista_id_espec varchar(12) references tb_especialista);
                                   
                                   
create table tb_feedback (id_feedback varchar(12) constraint feedback_id_pk primary key,
                          like_dislike_feedback number(1) constraint feedback_like_nn not null,
                          desc_feedback varchar2(1000) constraint feedback_desc_nn not null,
                          dt_feedback date constraint feedback_dt_nn not null,
                          fk_Cliente_id_clie varchar(12) references tb_cliente);
                          
--Cria tabela da entidade relacional                         
create table tb_Compra_Prod (fk_Compra varchar(12) references tb_compra,
                             fk_Produto varchar(12) references tb_produto);
                          

                        

                                                            

