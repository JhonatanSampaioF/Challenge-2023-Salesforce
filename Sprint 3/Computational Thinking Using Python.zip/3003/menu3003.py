# -*- coding: utf-8 -*-
'''
A partir dos dados coletados nas outras disciplinas, a equipe deverá desenvolver um
programa em Python, o qual deverá contemplar os seguintes itens:
• [35 pts] os dados deverão ser filtrados e armazenados em listas de dicionários;
• [35 pontos] tratamento de erros para a inserção e alteração dos dados
(try...except...else...finally);
• [30 pts] menu com submenus para acesso ao CRUD dos dados.
'''
import json


# Função main
def main():
    tb_formularioDuvida = []
    tb_cliente = []
    tb_especialista = []
    cont = 1
    while cont == 1:
        print("1 - Cliente"
              "\n2 - Especialista"
              "\n3 - Formulário")

        opc = int(input("Digite a opção desejada: "))

        match opc:
            case 1:
                print("1 - Inserir"
                      "\n2 - Exibir"
                      "\n3 - Atualizar"
                      "\n4 - Excluir"
                      "\n5 - Importar"
                      "\n6 - Exportar")

                opc = int(input("Digite a opção desejada: "))

                match opc:
                    case 1:
                        inserir_cliente(tb_cliente)
                    case 2:
                        print("1 - Buscar cliente")
                        print("2 - Exibir todos")

                        opc = int(input("Digite a opção desejada: "))

                        match opc:
                            case 1:
                                id = input("Digite o código do cliente: ")
                                for chave, valor in tb_cliente[buscar(tb_cliente, id,'id_clie')].items():
                                    print(f"{chave}: {valor}")
                            case 2:
                                exibir(tb_cliente, "Cliente")
                            case _:
                                print("Opção inválida!")
                    case 3:
                        id = input("Digite o código do cliente: ")
                        atualizar_cliente(tb_cliente, id)
                    case 4:
                        id = input("Digite o código do cliente: ")
                        excluir(tb_cliente, id, "Cliente",'id_clie')
                    case 5:
                        importar(tb_cliente, "Cliente")
                    case 6:
                        exportar(tb_cliente, "Cliente")
                    case _:
                        print("Opção inválida!")
            case 2:
                print("1 - Inserir"
                      "\n2 - Exibir"
                      "\n3 - Atualizar"
                      "\n4 - Excluir"
                      "\n5 - Importar"
                      "\n6 - Exportar")

                opc = int(input("Digite a opção desejada: "))

                match opc:
                    case 1:
                        inserir_especialista(tb_especialista)
                    case 2:
                        print("1 - Buscar especialista")
                        print("2 - Exibir todos")

                        opc = int(input("Digite a opção desejada: "))

                        match opc:
                            case 1:
                                id = input("Digite o código do especialista: ")
                                for chave, valor in tb_especialista[buscar(tb_especialista, id, 'id_espec')].items():
                                    print(f"{chave}: {valor}")
                            case 2:
                                exibir(tb_especialista, "Especialista")
                            case _:
                                print("Opção inválida!")
                    case 3:
                        id = input("Digite o código do especialista: ")
                        atualizar_especialista(tb_especialista, id)
                    case 4:
                        id = input("Digite o código do especialista: ")
                        excluir(tb_especialista, id, "Especialista", 'id_espec')
                    case 5:
                        importar(tb_especialista, "Especialista")
                    case 6:
                        exportar(tb_especialista, "Especialista")
                    case _:
                        print("Opção inválida!")
            case 3:
                print("1 - Inserir"
                      "\n2 - Exibir"
                      "\n3 - Atualizar"
                      "\n4 - Excluir"
                      "\n5 - Importar"
                      "\n6 - Exportar")

                opc = int(input("Digite a opção desejada: "))

                match opc:
                    case 1:
                        inserir_formularioDuvida(tb_formularioDuvida)
                    case 2:
                        print("1 - Buscar formulário")
                        print("2 - Exibir todos")

                        opc = int(input("Digite a opção desejada: "))

                        match opc:
                            case 1:
                                id = input("Digite o código do formulário: ")
                                for chave, valor in tb_formularioDuvida[
                                    buscar(tb_formularioDuvida, id, 'id_form')].items():
                                    print(f"{chave}: {valor}")
                            case 2:
                                exibir(tb_formularioDuvida, "Formulário")
                            case _:
                                print("Opção inválida!")
                    case 3:
                        id = input("Digite o código do formulário: ")
                        atualizar_formularioDuvida(tb_formularioDuvida, id)
                    case 4:
                        id = input("Digite o código do formulário: ")
                        excluir(tb_formularioDuvida, id, "Formulário", 'id_form')
                    case 5:
                        importar(tb_formularioDuvida, "Formulário")
                    case 6:
                        exportar(tb_formularioDuvida, "Formulário")
                    case _:
                        print("Opção inválida!")
            case _:
                print("Opção inválida!")

        cont = int(input("Deseja realizar outra operação? (1-SIM/0-NÃO): "))


def buscar(tabela, id, nm_id):
    indice = -1
    for i in range(len(tabela)):
        if tabela[i][f'{nm_id}'] == id:
            indice = i
    return indice

def inserir_cliente(tabela):
    try:
        cont = 1
        while cont == 1:
            id = input(f"Digite o ID do cliente: ")
            indice = buscar(tabela,id,'id_clie')
            if indice == -1:
                cont = 0
            else:
                print("ID já cadastrado!")
        nome = input("Digite o nome do cliente: ")
        sobrenome = input("Digite o sobrenome do cliente: ")
        email = input("Digite o email do cliente: ")
        empresa = input("Digite a empresa do cliente: ")
        tamanho_empresa = int(input("Digite o tamanho da empresa do cliente: "))
        pais = input("Digite o país do cliente (2 dígitos): ")
        idioma = input("Digite o idioma do cliente: ")
        cargo = input("Digite o cargo do cliente: ")
        telefone = input("Digite o telefone do cliente: ")
    except ValueError:
        print("Insira dados numéricos para o tamanho da empresa!")
    else:
        cliente = {'id_clie': id, 'nm_clie': nome, 'sobrenome': sobrenome, 'email': email,
                   'empresa': empresa, 'tamanho_empresa': tamanho_empresa,
                   'pais': pais, 'idioma': idioma, 'cargo': cargo, 'telefone': telefone}
        tabela.append(cliente)
        print("Cliente adicionado com sucesso!")
    finally:
        print("Operação finalizada!")


def inserir_especialista(tabela):
    try:
        cont = 1
        while cont == 1:
            id = input(f"Digite o ID do especialista: ")
            indice = buscar(tabela, id,'id_espec')
            if indice == -1:
                cont = 0
            else:
                print("ID já cadastrado!")
        nome = input("Digite o nome do especialista: ")
        email = input("Digite o email do especialista: ")
        telefone = input("Digite o telefone do especialista: ")
    except Exception:
        print("Insira os dados solicitados!")
    else:
        especialista = {'id_espec': id, 'nm_espec': nome, 'email_espec': email,
                        'telefone_espec': telefone}
        tabela.append(especialista)
        print("Especialista adicionado com sucesso!")
    finally:
        print("Operação finalizada!")


def inserir_formularioDuvida(tabela):
    try:
        cont = 1
        while cont == 1:
            id = input(f"Digite o ID do formulário: ")
            indice = buscar(tabela, id,'id_form')
            if indice == -1:
                cont = 0
            else:
                print("ID já cadastrado!")
        data = input("Digite a data do formulário no formato (DD/MM/YYYY): ")
        desc = input("Digite a dúvida: ")
        seg_empresa = input("Digite o segmento da empresa: ")
        id_clie = input("Digite o id do cliente: ")
        id_espec = input("Digite o id do especialista: ")
    except ValueError:
        print("Insira a data corretamente!")
    else:
        formularioDuvidas = {'id_form': id, 'dt_form': data, 'desc_form': desc,
                             'seg_empresa': seg_empresa, 'fk_Cliente_id_clie': id_clie,
                             'fk_Especialista_id_espec': id_espec}
        tabela.append(formularioDuvidas)
        print("Formulário adicionado com sucesso!")
    finally:
        print("Operação finalizada!")


def exibir(tabela, objeto):
    for i in range(len(tabela)):
        print(f"{objeto} {i + 1}")
        for chave, valor in tabela[i].items():
            print(f"{chave}: {valor}")
        print("---------------------")


def atualizar_cliente(tabela, id):
    indice = buscar(tabela, id,'id_clie')
    if indice == -1:
        print("Código incorreto!")
    else:
        try:
            nome = input("Digite o novo nome do cliente: ")
            sobrenome = input("Digite o novo sobrenome do cliente: ")
            email = input("Digite o novo email do cliente: ")
            empresa = input("Digite a novo empresa do cliente: ")
            tamanho_empresa = int(input("Digite o novo tamanho da empresa do cliente: "))
            pais = input("Digite o novo país do cliente (2 dígitos): ")
            idioma = input("Digite o novo idioma do cliente: ")
            cargo = input("Digite o novo cargo docliente: ")
            telefone = input("Digite o novo telefone do cliente: ")
        except ValueError:
            print("Insira dados numéricos para o tamanho da empresa!")
        else:
            tabela[indice]['nm_clie'] = nome
            tabela[indice]['sobrenome'] = sobrenome
            tabela[indice]['email'] = email
            tabela[indice]['empresa'] = empresa
            tabela[indice]['tamanho_empresa'] = tamanho_empresa
            tabela[indice]['pais'] = pais
            tabela[indice]['idioma'] = idioma
            tabela[indice]['cargo'] = cargo
            tabela[indice]['telefone'] = telefone
            print("Cliente atualizado com sucesso!")
        finally:
            print("Operação finalizada!")


def atualizar_especialista(tabela, id):
    indice = buscar(tabela, id,'id_espec')
    if indice == -1:
        print("Código incorreto!")
    else:
        try:
            nome = input("Digite o novo nome do especialista: ")
            email = input("Digite o novo email do especialista: ")
            telefone = input("Digite o novo telefone do especialista: ")
        except Exception:
            print("Insira os dados solicitados!")
        else:
            tabela[indice]['nm_espec'] = nome
            tabela[indice]['email'] = email
            tabela[indice]['telefone'] = telefone
            print("Especialista atualizado com sucesso!")
        finally:
            print("Operação finalizada!")


def atualizar_formularioDuvida(tabela, id):
    indice = buscar(tabela, id,'id_form')
    if indice == -1:
        print("Código incorreto!")
    else:
        try:
            data = input("Digite a nova data do formulário no formato (DD/MM/YYYY): ")
            desc = input("Digite a nova dúvida: ")
            seg_empresa = input("Digite o novo segmento da empresa: ")
            id_clie = input("Digite o novo id do cliente: ")
            id_espec = input("Digite o novo id do especialista: ")
        except ValueError:
            print("Insira a data corretamente!")
        else:
            tabela[indice]['dt_form'] = data
            tabela[indice]['desc_form'] = desc
            tabela[indice]['seg_empresa'] = seg_empresa
            tabela[indice]['fk_Cliente_id_clie'] = id_clie
            tabela[indice]['fk_Especialista_id_espec'] = id_espec
            print("Formulário atualizado com sucesso!")
        finally:
            print("Operação finalizada!")


def excluir(tabela, id, objeto,nm_id):
    indice = buscar(tabela, id,nm_id)
    if indice == -1:
        print("Código incorreto!")
    else:
        tabela.pop(indice)
        print(f"{objeto} excluído com sucesso!")


def importar(tabela, objeto):
    path = input("Insira o caminho do arquivo json (com o formato .json no final): ")
    with open(path, "r", encoding="utf-8") as arq:
        arqJson = arq.read()
        lista = json.loads(arqJson)
        for i in range(len(lista)):
            tabela.append(lista[i])
    print(f"{objeto} importado com sucesso!")


def exportar(tabela, objeto):
    path = input("Insira o nome do arquivo (sem o formato): ")
    with open(f"{path}.json", "w", encoding="utf-8") as arq:
        json.dump(tabela, arq, indent=4, ensure_ascii=False)
    print(f"{objeto} exportado com sucesso!")


if __name__ == "__main__":
    main()
