NOME				RM
JHONATAN SAMPAIO FERREIRA	553791
LEVI YUKI UTIMA			553580
VIVIAN SY TING WU		553169


## INSTRUÇÕES PARA UTILIZAÇÃO DO PROGRAMA
# Após iniciar a aplicação, selecione qual tópico deseja acessar o submenu.

# Após selecionar qual tópico deseja acessar, selecione qual ação deseja realizar.

# Caso deseje criar um novo objeto da lista principal selecionada, insira “1” e então as informações solicitadas.

# Após realizar cada operação, o programa irá perguntar se deseja realizar outra operação, selecione digitando “1” para sim e “0” para encerrar o programa.

# Caso deseje visualizar o objeto inserido, no submenu selecione “2” e então selecione como deseja visualizar, se são todos os objetos ou apenas um específico.

# Caso deseje visualizar apenas um objeto específico, selecione “1” e então digite o ID do objeto.

# Caso deseje atualizar a informação de algum objeto, você pode realizar selecionando a opção “3” no submenu, inserindo o ID do objeto a ser alterado e então inserindo as novas informações

# Caso deseje excluir um objeto, selecione a opção “4” no submenu e insira o ID do objeto a ser excluído.

# Caso deseje importar uma lista de objetos, selecione a opção “5” no submenu e insira o caminho do arquivo json com o formato .json no final

# Caso deseje exportar os objetos, selecione a opção “6” e insira o nome do arquivo sem o .json no final, ele será salvo na mesma pasta em que o programa se encontra

# Todas as operações podem ser executadas da mesma maneira para todos os objetos declarados no menu principal