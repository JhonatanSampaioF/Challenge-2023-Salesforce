VÍDEO EXPLICAÇÃO NO YOUTUBE:

https://youtu.be/aOn2fdp16Yk

REPOSITÓRIO DO GIT:

https://github.com/VivianSTWu/Challenge-Salesforce-ReactJS